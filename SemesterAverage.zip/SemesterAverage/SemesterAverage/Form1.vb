﻿'Author:	   	 Brennan Kerr
'Date:		     February 5th 2019
'File Name:		 SemesterAverage
'Project Name:	 Lab 2 - Semester Average
'Description:	 Takes user input for six courses and determines the average.
'				 only allows numeric input between 0 and 100 inclusive

Option Strict On

Public Class Form1
	' CONSTANTS ------------
	Const MAX_GRADE As Double = 100.0   ' the maximum grade that can be entered
	Const MIN_GRADE As Double = 0.0     ' the minimum grade that can be entered
	Const NumOfCourses As Integer = 6 ' the number of courses that require input

	'Veriables
	Dim errors As String        ' saves any logic errors in the program
	Dim letterGrade As String   ' saves the current letter grade (the latest entry)
	Dim total As Double         'Adds all the numeric values of the student
	Dim average As Double       ' determines the average numeric grade from the total

	Dim validInput(NumOfCourses) As Boolean    ' determines if the input is valid (false means invalid)
	Dim tbOutput(NumOfCourses) As TextBox      ' saves all the output textboxes to an array
	Dim tbInput(NumOfCourses) As TextBox       ' saves all the input textboxes to an array
	Dim tbLostFocus(NumOfCourses) As Boolean   ' determines if the textbox has lost focus
	Dim numericValues(NumOfCourses) As Double  ' determines if a numeric value has been entered to the textbox

	Private Sub Form1_Load(sender As Object, e As EventArgs) Handles MyBase.Load
		'saves all the output textboxes to an array
		tbOutput(1) = tbOneOutput
		tbOutput(2) = tbTwoOutput
		tbOutput(3) = tbThreeOutput
		tbOutput(4) = tbFourOutput
		tbOutput(5) = tbFiveOutput
		tbOutput(6) = tbSixOutput
		'saves all the input textboxes to an array
		tbInput(1) = tbOneInput
		tbInput(2) = tbTwoInput
		tbInput(3) = tbThreeInput
		tbInput(4) = tbFourInput
		tbInput(5) = tbFiveInput
		tbInput(6) = tbSixInput
	End Sub

	'gets the textbox that lost focus and sends the information to ValidateInput
	Private Sub firstCourseInput(sender As Object, e As EventArgs) Handles tbOneInput.LostFocus, tbTwoInput.LostFocus, tbThreeInput.LostFocus, tbFourInput.LostFocus, tbFiveInput.LostFocus, tbSixInput.LostFocus
		'Dim currentTB As TextBox = CType(sender, TextBox)       ' saves the current textbox (which ever one lost focus)
		Dim currentNumber As Integer = CType(sender, TextBox).TabIndex + 1   ' saves the number of the textbox

		tbLostFocus(currentNumber) = True   ' states that the current textbox has lost focus

		ValidateInput(currentNumber) ' sends the information to the method 'ValidateInput' to determine if the input is numeric
	End Sub

	' validates the input
	Private Sub ValidateInput(tbNumber As Integer)
		Dim currentTB As TextBox = tbInput(tbNumber)
		Dim numericGrade As Double ' saves the current textboxes numeric value

		' if the input numeric
		If Double.TryParse(currentTB.Text, numericGrade) Then
			' is the input in the numeric range
			If (numericGrade >= MIN_GRADE And numericGrade <= MAX_GRADE) Then
				DetermineLetter(numericGrade)
				validInput(tbNumber) = True
				tbOutput(tbNumber).Text = letterGrade
			Else
				InvalidInput(tbNumber)
			End If
			' if nothing is entered
		ElseIf currentTB.Text = "" Then
			tbOutput(tbNumber).Text = ""
			validInput(tbNumber) = False
			'If something is entered but is not a number
		Else
			InvalidInput(tbNumber)
		End If

		' displays any errors that may occur
		ErrorOutput()
	End Sub

	Public Sub InvalidInput(tbNumber As Integer)
		tbOutput(tbNumber).Text = ""
		validInput(tbNumber) = False
		tbInput(tbNumber).Focus()
		tbInput(tbNumber).SelectAll()
	End Sub

	' determines which letter to assign to the grade
	Public Sub DetermineLetter(numericGrade As Double)
		'If it is in the 'A' range
		If (numericGrade >= 90) Then
			letterGrade = "A+"
		ElseIf (numericGrade >= 85) Then
			letterGrade = "A"
		ElseIf (numericGrade >= 80) Then
			letterGrade = "A"

			'If it is in the 'B' range
		ElseIf (numericGrade >= 77) Then
			letterGrade = "B+"
		ElseIf (numericGrade >= 73) Then
			letterGrade = "B"
		ElseIf (numericGrade >= 70) Then
			letterGrade = "B-"

			'If it is in the 'C' range
		ElseIf (numericGrade >= 67) Then
			letterGrade = "C+"
		ElseIf (numericGrade >= 63) Then
			letterGrade = "C"
		ElseIf (numericGrade >= 60) Then
			letterGrade = "C-"

			'If it is in the 'D' range
		ElseIf (numericGrade >= 57) Then
			letterGrade = "D+"
		ElseIf (numericGrade >= 53) Then
			letterGrade = "D"
		ElseIf (numericGrade >= 50) Then
			letterGrade = "D-"

			'If it is a fail
		Else
			letterGrade = "F"
		End If
	End Sub

	' displays any errors
	Public Sub ErrorOutput()
		' creates a string that is used for the error textbox header
		Dim outputText As String = "Error(s)" + Environment.NewLine

		' checks to see if there are any errors, if there are, display them
		For count = 1 To NumOfCourses
			If validInput(count) = False And tbLostFocus(count) = True Then
				outputText = outputText + "Please ensure that Course " + count.ToString() + " has a numeric input between " + MIN_GRADE.ToString() + " and " + MAX_GRADE.ToString() + "!" + Environment.NewLine
			End If
		Next

		' displays any and all errors in the error textbox
		tbErrors.Text = outputText
	End Sub

	'if the exit button is clicked, the application closes
	Private Sub btnExit_Click(sender As Object, e As EventArgs) Handles btnExit.Click
		Close()
	End Sub

	'
	Private Sub btnCalculate_Click(sender As Object, e As EventArgs) Handles btnCalculate.Click

		Dim numOfValidInput As Integer = 0  'used to determine how many courses have valid input

		'checks each course to see if it has valid input, adds one if it is valid
		For count = 1 To NumOfCourses
			If (validInput(count)) Then
				numOfValidInput = numOfValidInput + 1
			End If
		Next

		' checks to see if all courses are valid, if so disables the calculate button and input textboxes.
		' gets the total of all courses
		If (numOfValidInput = NumOfCourses) Then
			btnCalculate.Enabled = False
			For count = 1 To NumOfCourses
				tbInput(count).Enabled = False
				numericValues(count) = Convert.ToDouble(tbInput(count).Text)
				total = total + numericValues(count)
			Next

			' determines the average
			average = Math.Round(total / NumOfCourses, 2)

			' displays the average
			tbAvgInput.Text = average.ToString
			DetermineLetter(average)
			tbAvgOutput.Text = letterGrade
		End If

	End Sub

	'reset the application
	Private Sub btnReset_Click(sender As Object, e As EventArgs) Handles btnReset.Click
		tbErrors.Clear() ' clears the errors textbox.

		' resets focus to the first course.
		tbInput(1).Focus()

		' resets the total and clears the average textboxes
		total = 0
		tbAvgOutput.Clear()
		tbAvgInput.Clear()

		' enables all controls and resets any booleans
		btnCalculate.Enabled = True
		For count = 1 To NumOfCourses
			tbInput(count).Enabled = True
			validInput(count) = False
			tbLostFocus(count) = False
			tbOutput(count).Clear()
			tbInput(count).Clear()
		Next
	End Sub
End Class
