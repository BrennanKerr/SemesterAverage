﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()>
Partial Class Form1
	Inherits System.Windows.Forms.Form

	'Form overrides dispose to clean up the component list.
	<System.Diagnostics.DebuggerNonUserCode()>
	Protected Overrides Sub Dispose(ByVal disposing As Boolean)
		Try
			If disposing AndAlso components IsNot Nothing Then
				components.Dispose()
			End If
		Finally
			MyBase.Dispose(disposing)
		End Try
	End Sub

	'Required by the Windows Form Designer
	Private components As System.ComponentModel.IContainer

	'NOTE: The following procedure is required by the Windows Form Designer
	'It can be modified using the Windows Form Designer.  
	'Do not modify it using the code editor.
	<System.Diagnostics.DebuggerStepThrough()>
	Private Sub InitializeComponent()
		Me.components = New System.ComponentModel.Container()
		Me.lbCourseOne = New System.Windows.Forms.Label()
		Me.tbOneInput = New System.Windows.Forms.TextBox()
		Me.tbOneOutput = New System.Windows.Forms.TextBox()
		Me.tbTwoOutput = New System.Windows.Forms.TextBox()
		Me.tbTwoInput = New System.Windows.Forms.TextBox()
		Me.lbCourseTwo = New System.Windows.Forms.Label()
		Me.tbThreeOutput = New System.Windows.Forms.TextBox()
		Me.tbThreeInput = New System.Windows.Forms.TextBox()
		Me.lbCourseThree = New System.Windows.Forms.Label()
		Me.tbFourOutput = New System.Windows.Forms.TextBox()
		Me.tbFourInput = New System.Windows.Forms.TextBox()
		Me.lbCourseFour = New System.Windows.Forms.Label()
		Me.tbFiveOutput = New System.Windows.Forms.TextBox()
		Me.tbFiveInput = New System.Windows.Forms.TextBox()
		Me.lbCourseFive = New System.Windows.Forms.Label()
		Me.tbSixOutput = New System.Windows.Forms.TextBox()
		Me.tbSixInput = New System.Windows.Forms.TextBox()
		Me.lbCourseSix = New System.Windows.Forms.Label()
		Me.tbAvgOutput = New System.Windows.Forms.TextBox()
		Me.tbAvgInput = New System.Windows.Forms.TextBox()
		Me.lbSemester = New System.Windows.Forms.Label()
		Me.tbErrors = New System.Windows.Forms.TextBox()
		Me.btnCalculate = New System.Windows.Forms.Button()
		Me.btnReset = New System.Windows.Forms.Button()
		Me.btnExit = New System.Windows.Forms.Button()
		Me.ToolTip1 = New System.Windows.Forms.ToolTip(Me.components)
		Me.SuspendLayout()
		'
		'lbCourseOne
		'
		Me.lbCourseOne.Location = New System.Drawing.Point(40, 15)
		Me.lbCourseOne.Name = "lbCourseOne"
		Me.lbCourseOne.Size = New System.Drawing.Size(52, 13)
		Me.lbCourseOne.TabIndex = 0
		Me.lbCourseOne.Text = "Course 1:"
		Me.lbCourseOne.TextAlign = System.Drawing.ContentAlignment.MiddleRight
		'
		'tbOneInput
		'
		Me.tbOneInput.Location = New System.Drawing.Point(98, 12)
		Me.tbOneInput.Name = "tbOneInput"
		Me.tbOneInput.Size = New System.Drawing.Size(85, 20)
		Me.tbOneInput.TabIndex = 0
		Me.tbOneInput.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
		Me.ToolTip1.SetToolTip(Me.tbOneInput, "Enter a numeric grade of Course 1:" & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10) & "Grade needs to be between 0 and 100 inclusive" &
		".")
		'
		'tbOneOutput
		'
		Me.tbOneOutput.Location = New System.Drawing.Point(189, 12)
		Me.tbOneOutput.Name = "tbOneOutput"
		Me.tbOneOutput.ReadOnly = True
		Me.tbOneOutput.Size = New System.Drawing.Size(85, 20)
		Me.tbOneOutput.TabIndex = 1
		Me.tbOneOutput.TabStop = False
		Me.tbOneOutput.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
		Me.ToolTip1.SetToolTip(Me.tbOneOutput, "Displays the equivalent letter grade once a valid" & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10) & "grade has been entered.")
		'
		'tbTwoOutput
		'
		Me.tbTwoOutput.Location = New System.Drawing.Point(189, 38)
		Me.tbTwoOutput.Name = "tbTwoOutput"
		Me.tbTwoOutput.ReadOnly = True
		Me.tbTwoOutput.Size = New System.Drawing.Size(85, 20)
		Me.tbTwoOutput.TabIndex = 11
		Me.tbTwoOutput.TabStop = False
		Me.tbTwoOutput.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
		Me.ToolTip1.SetToolTip(Me.tbTwoOutput, "Displays the equivalent letter grade once a valid" & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10) & "grade has been entered.")
		'
		'tbTwoInput
		'
		Me.tbTwoInput.Location = New System.Drawing.Point(98, 38)
		Me.tbTwoInput.Name = "tbTwoInput"
		Me.tbTwoInput.Size = New System.Drawing.Size(85, 20)
		Me.tbTwoInput.TabIndex = 1
		Me.tbTwoInput.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
		Me.ToolTip1.SetToolTip(Me.tbTwoInput, "Enter a numeric grade of Course 2:" & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10) & "Grade needs to be between 0 and 100 inclusive" &
		".")
		'
		'lbCourseTwo
		'
		Me.lbCourseTwo.Location = New System.Drawing.Point(40, 41)
		Me.lbCourseTwo.Name = "lbCourseTwo"
		Me.lbCourseTwo.Size = New System.Drawing.Size(52, 13)
		Me.lbCourseTwo.TabIndex = 9
		Me.lbCourseTwo.Text = "Course 2:"
		Me.lbCourseTwo.TextAlign = System.Drawing.ContentAlignment.MiddleRight
		'
		'tbThreeOutput
		'
		Me.tbThreeOutput.Location = New System.Drawing.Point(189, 64)
		Me.tbThreeOutput.Name = "tbThreeOutput"
		Me.tbThreeOutput.ReadOnly = True
		Me.tbThreeOutput.Size = New System.Drawing.Size(85, 20)
		Me.tbThreeOutput.TabIndex = 14
		Me.tbThreeOutput.TabStop = False
		Me.tbThreeOutput.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
		Me.ToolTip1.SetToolTip(Me.tbThreeOutput, "Displays the equivalent letter grade once a valid" & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10) & "grade has been entered.")
		'
		'tbThreeInput
		'
		Me.tbThreeInput.Location = New System.Drawing.Point(98, 64)
		Me.tbThreeInput.Name = "tbThreeInput"
		Me.tbThreeInput.Size = New System.Drawing.Size(85, 20)
		Me.tbThreeInput.TabIndex = 2
		Me.tbThreeInput.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
		Me.ToolTip1.SetToolTip(Me.tbThreeInput, "Enter a numeric grade of Course 3:" & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10) & "Grade needs to be between 0 and 100 inclusive" &
		".")
		'
		'lbCourseThree
		'
		Me.lbCourseThree.Location = New System.Drawing.Point(40, 67)
		Me.lbCourseThree.Name = "lbCourseThree"
		Me.lbCourseThree.Size = New System.Drawing.Size(52, 13)
		Me.lbCourseThree.TabIndex = 12
		Me.lbCourseThree.Text = "Course 3:"
		Me.lbCourseThree.TextAlign = System.Drawing.ContentAlignment.MiddleRight
		'
		'tbFourOutput
		'
		Me.tbFourOutput.Location = New System.Drawing.Point(189, 90)
		Me.tbFourOutput.Name = "tbFourOutput"
		Me.tbFourOutput.ReadOnly = True
		Me.tbFourOutput.Size = New System.Drawing.Size(85, 20)
		Me.tbFourOutput.TabIndex = 17
		Me.tbFourOutput.TabStop = False
		Me.tbFourOutput.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
		Me.ToolTip1.SetToolTip(Me.tbFourOutput, "Displays the equivalent letter grade once a valid" & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10) & "grade has been entered.")
		'
		'tbFourInput
		'
		Me.tbFourInput.Location = New System.Drawing.Point(98, 90)
		Me.tbFourInput.Name = "tbFourInput"
		Me.tbFourInput.Size = New System.Drawing.Size(85, 20)
		Me.tbFourInput.TabIndex = 3
		Me.tbFourInput.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
		Me.ToolTip1.SetToolTip(Me.tbFourInput, "Enter a numeric grade of Course 4:" & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10) & "Grade needs to be between 0 and 100 inclusive" &
		".")
		'
		'lbCourseFour
		'
		Me.lbCourseFour.Location = New System.Drawing.Point(40, 93)
		Me.lbCourseFour.Name = "lbCourseFour"
		Me.lbCourseFour.Size = New System.Drawing.Size(52, 13)
		Me.lbCourseFour.TabIndex = 15
		Me.lbCourseFour.Text = "Course 4:"
		Me.lbCourseFour.TextAlign = System.Drawing.ContentAlignment.MiddleRight
		'
		'tbFiveOutput
		'
		Me.tbFiveOutput.Location = New System.Drawing.Point(189, 116)
		Me.tbFiveOutput.Name = "tbFiveOutput"
		Me.tbFiveOutput.ReadOnly = True
		Me.tbFiveOutput.Size = New System.Drawing.Size(85, 20)
		Me.tbFiveOutput.TabIndex = 20
		Me.tbFiveOutput.TabStop = False
		Me.tbFiveOutput.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
		Me.ToolTip1.SetToolTip(Me.tbFiveOutput, "Displays the equivalent letter grade once a valid" & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10) & "grade has been entered.")
		'
		'tbFiveInput
		'
		Me.tbFiveInput.Location = New System.Drawing.Point(98, 116)
		Me.tbFiveInput.Name = "tbFiveInput"
		Me.tbFiveInput.Size = New System.Drawing.Size(85, 20)
		Me.tbFiveInput.TabIndex = 4
		Me.tbFiveInput.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
		Me.ToolTip1.SetToolTip(Me.tbFiveInput, "Enter a numeric grade of Course 5:" & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10) & "Grade needs to be between 0 and 100 inclusive" &
		".")
		'
		'lbCourseFive
		'
		Me.lbCourseFive.Location = New System.Drawing.Point(40, 119)
		Me.lbCourseFive.Name = "lbCourseFive"
		Me.lbCourseFive.Size = New System.Drawing.Size(52, 13)
		Me.lbCourseFive.TabIndex = 18
		Me.lbCourseFive.Text = "Course 5:"
		Me.lbCourseFive.TextAlign = System.Drawing.ContentAlignment.MiddleRight
		'
		'tbSixOutput
		'
		Me.tbSixOutput.Location = New System.Drawing.Point(189, 142)
		Me.tbSixOutput.Name = "tbSixOutput"
		Me.tbSixOutput.ReadOnly = True
		Me.tbSixOutput.Size = New System.Drawing.Size(85, 20)
		Me.tbSixOutput.TabIndex = 23
		Me.tbSixOutput.TabStop = False
		Me.tbSixOutput.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
		Me.ToolTip1.SetToolTip(Me.tbSixOutput, "Displays the equivalent letter grade once a valid" & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10) & "grade has been entered.")
		'
		'tbSixInput
		'
		Me.tbSixInput.Location = New System.Drawing.Point(98, 142)
		Me.tbSixInput.Name = "tbSixInput"
		Me.tbSixInput.Size = New System.Drawing.Size(85, 20)
		Me.tbSixInput.TabIndex = 5
		Me.tbSixInput.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
		Me.ToolTip1.SetToolTip(Me.tbSixInput, "Enter a numeric grade of Course 6:" & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10) & "Grade needs to be between 0 and 100 inclusive" &
		".")
		'
		'lbCourseSix
		'
		Me.lbCourseSix.Location = New System.Drawing.Point(40, 145)
		Me.lbCourseSix.Name = "lbCourseSix"
		Me.lbCourseSix.Size = New System.Drawing.Size(52, 13)
		Me.lbCourseSix.TabIndex = 21
		Me.lbCourseSix.Text = "Course 6:"
		Me.lbCourseSix.TextAlign = System.Drawing.ContentAlignment.MiddleRight
		'
		'tbAvgOutput
		'
		Me.tbAvgOutput.Location = New System.Drawing.Point(189, 168)
		Me.tbAvgOutput.Name = "tbAvgOutput"
		Me.tbAvgOutput.ReadOnly = True
		Me.tbAvgOutput.Size = New System.Drawing.Size(85, 20)
		Me.tbAvgOutput.TabIndex = 26
		Me.tbAvgOutput.TabStop = False
		Me.tbAvgOutput.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
		Me.ToolTip1.SetToolTip(Me.tbAvgOutput, "Displays the average letter grade once all 6 courses" & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10) & "have valid input.")
		'
		'tbAvgInput
		'
		Me.tbAvgInput.Location = New System.Drawing.Point(98, 168)
		Me.tbAvgInput.Name = "tbAvgInput"
		Me.tbAvgInput.ReadOnly = True
		Me.tbAvgInput.Size = New System.Drawing.Size(85, 20)
		Me.tbAvgInput.TabIndex = 25
		Me.tbAvgInput.TabStop = False
		Me.tbAvgInput.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
		Me.ToolTip1.SetToolTip(Me.tbAvgInput, "Displays the average numeric grade once 6 courses only" & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10) & "if the 6 courses have val" &
		"id input.")
		'
		'lbSemester
		'
		Me.lbSemester.Location = New System.Drawing.Point(40, 171)
		Me.lbSemester.Name = "lbSemester"
		Me.lbSemester.Size = New System.Drawing.Size(52, 13)
		Me.lbSemester.TabIndex = 24
		Me.lbSemester.Text = "Semester:"
		Me.lbSemester.TextAlign = System.Drawing.ContentAlignment.MiddleRight
		'
		'tbErrors
		'
		Me.tbErrors.Location = New System.Drawing.Point(12, 194)
		Me.tbErrors.Multiline = True
		Me.tbErrors.Name = "tbErrors"
		Me.tbErrors.ReadOnly = True
		Me.tbErrors.Size = New System.Drawing.Size(262, 184)
		Me.tbErrors.TabIndex = 0
		Me.tbErrors.TabStop = False
		Me.ToolTip1.SetToolTip(Me.tbErrors, "Displays any and all errors." & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10) & "Will state which courses have the errors.")
		'
		'btnCalculate
		'
		Me.btnCalculate.Location = New System.Drawing.Point(37, 384)
		Me.btnCalculate.Name = "btnCalculate"
		Me.btnCalculate.Size = New System.Drawing.Size(75, 23)
		Me.btnCalculate.TabIndex = 28
		Me.btnCalculate.Text = "&Calculate"
		Me.ToolTip1.SetToolTip(Me.btnCalculate, "Once pressed, will determines the average if all the" & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10) & "courses have valid input." & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10) &
		"Can also be accessed by pressing 'Enter' or 'Alt+C'.")
		Me.btnCalculate.UseVisualStyleBackColor = True
		'
		'btnReset
		'
		Me.btnReset.DialogResult = System.Windows.Forms.DialogResult.Cancel
		Me.btnReset.Location = New System.Drawing.Point(118, 384)
		Me.btnReset.Name = "btnReset"
		Me.btnReset.Size = New System.Drawing.Size(75, 23)
		Me.btnReset.TabIndex = 29
		Me.btnReset.Text = "&Reset"
		Me.ToolTip1.SetToolTip(Me.btnReset, "Will reset the application to its base setup." & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10) & "All information will be lost." & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10) & "Can" &
		" also be accessed by pressing 'Esc' or 'Alt+R'.")
		Me.btnReset.UseVisualStyleBackColor = True
		'
		'btnExit
		'
		Me.btnExit.Location = New System.Drawing.Point(199, 384)
		Me.btnExit.Name = "btnExit"
		Me.btnExit.Size = New System.Drawing.Size(75, 23)
		Me.btnExit.TabIndex = 30
		Me.btnExit.Text = "E&xit"
		Me.ToolTip1.SetToolTip(Me.btnExit, "Close the application." & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10) & "All information will be lost." & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10) & "Can also be accessed by pr" &
		"essing 'Alt+X'.")
		Me.btnExit.UseVisualStyleBackColor = True
		'
		'Form1
		'
		Me.AcceptButton = Me.btnCalculate
		Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
		Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
		Me.CancelButton = Me.btnReset
		Me.ClientSize = New System.Drawing.Size(286, 412)
		Me.Controls.Add(Me.btnExit)
		Me.Controls.Add(Me.btnReset)
		Me.Controls.Add(Me.btnCalculate)
		Me.Controls.Add(Me.tbErrors)
		Me.Controls.Add(Me.tbAvgOutput)
		Me.Controls.Add(Me.tbAvgInput)
		Me.Controls.Add(Me.lbSemester)
		Me.Controls.Add(Me.tbSixOutput)
		Me.Controls.Add(Me.tbSixInput)
		Me.Controls.Add(Me.lbCourseSix)
		Me.Controls.Add(Me.tbFiveOutput)
		Me.Controls.Add(Me.tbFiveInput)
		Me.Controls.Add(Me.lbCourseFive)
		Me.Controls.Add(Me.tbFourOutput)
		Me.Controls.Add(Me.tbFourInput)
		Me.Controls.Add(Me.lbCourseFour)
		Me.Controls.Add(Me.tbThreeOutput)
		Me.Controls.Add(Me.tbThreeInput)
		Me.Controls.Add(Me.lbCourseThree)
		Me.Controls.Add(Me.tbTwoOutput)
		Me.Controls.Add(Me.tbTwoInput)
		Me.Controls.Add(Me.lbCourseTwo)
		Me.Controls.Add(Me.tbOneOutput)
		Me.Controls.Add(Me.tbOneInput)
		Me.Controls.Add(Me.lbCourseOne)
		Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.Fixed3D
		Me.MaximizeBox = False
		Me.MinimizeBox = False
		Me.Name = "Form1"
		Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen
		Me.Text = "Semester Grades"
		Me.ResumeLayout(False)
		Me.PerformLayout()

	End Sub

	Friend WithEvents lbCourseOne As Label
	Friend WithEvents tbOneInput As TextBox
	Friend WithEvents tbOneOutput As TextBox
	Friend WithEvents tbTwoOutput As TextBox
	Friend WithEvents tbTwoInput As TextBox
	Friend WithEvents lbCourseTwo As Label
	Friend WithEvents tbThreeOutput As TextBox
	Friend WithEvents tbThreeInput As TextBox
	Friend WithEvents lbCourseThree As Label
	Friend WithEvents tbFourOutput As TextBox
	Friend WithEvents tbFourInput As TextBox
	Friend WithEvents lbCourseFour As Label
	Friend WithEvents tbFiveOutput As TextBox
	Friend WithEvents tbFiveInput As TextBox
	Friend WithEvents lbCourseFive As Label
	Friend WithEvents tbSixOutput As TextBox
	Friend WithEvents tbSixInput As TextBox
	Friend WithEvents lbCourseSix As Label
	Friend WithEvents tbAvgOutput As TextBox
	Friend WithEvents tbAvgInput As TextBox
	Friend WithEvents lbSemester As Label
	Friend WithEvents tbErrors As TextBox
	Friend WithEvents btnCalculate As Button
	Friend WithEvents btnReset As Button
	Friend WithEvents btnExit As Button
	Friend WithEvents ToolTip1 As ToolTip
End Class
